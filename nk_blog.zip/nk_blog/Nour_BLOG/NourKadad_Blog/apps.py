from django.apps import AppConfig


class NourkadadBlogConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'NourKadad_Blog'
